#ifndef FILEIO_H
#define FILEIO_H

#include "shared.h"

void read_file(Image *img, char filename[]);


#endif