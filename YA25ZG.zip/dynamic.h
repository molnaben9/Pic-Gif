#ifndef DYNAMIC_H
#define DYNAMIC_H

#include "shared.h"

void initMatrixIn(Image *img);

void freeTheMatrixIn(Image *img);

#endif